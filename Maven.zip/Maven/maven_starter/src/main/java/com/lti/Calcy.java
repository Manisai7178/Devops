package com.lti;

public interface Calcy 
{
	public int add(int num1,int num2) throws IllegalArgumentException;
	public double div(int num1,int num2)throws IllegalArgumentException;
}
