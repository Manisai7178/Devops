package com.lti;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.lti.bean.Customer;
import com.lti.service.CustomerService;
import com.lti.service.CustomerServiceImpl;

public class Main {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		int choice, custId, result;
		String custName;
		double balance;
		
		CustomerService service = new CustomerServiceImpl();
		Scanner sc = new Scanner(System.in);
		
		List<Customer> custList = null;
		
		while(true){
			System.out.println("-----------------------------Customer Management-----------------------------");
			System.out.println("\n1. Add \n2. Delete \n3. View \n4. Exit");
			System.out.print("\nEnter Choice: ");
			choice = sc.nextInt();
			
			switch(choice){
			case 1:
				System.out.print("\nEnter Id: ");
				custId = sc.nextInt();
				sc.nextLine();
				System.out.print("\nEnter Name: ");
				custName = sc.nextLine();
				System.out.print("\nEnter Balance: ");
				balance = sc.nextDouble();
				
				result = service.addCustomer(custId, custName, balance);
				
				System.out.println(result+" row added.");
				
				break;
			case 2: 	
				System.out.print("\nEnter Id: ");
				custId = sc.nextInt();
				
				result = service.deleteCustomer(custId);
				System.out.println(result+" row(s) deleted.");
				break;
			case 3: 	
				custList = service.getAllCustomers();
				
				for (Customer customer : custList) {
					System.out.println(customer);
				}
				break;
			case 4: 	System.exit(0);;
			default:	System.out.println("Invalid Input!");
			
			}
		}

	}

}
