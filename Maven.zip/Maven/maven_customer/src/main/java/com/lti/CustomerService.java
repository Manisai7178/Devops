package com.lti;

public interface CustomerService 
{

}
