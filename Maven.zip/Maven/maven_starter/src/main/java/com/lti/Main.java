package com.lti;

public class Main {

	public static void main(String[] args) {
		Calcy c=new CalcyImpl();
		int result=c.add(1000,10011);
		System.out.println("Result :"+result);
			

	}

}
