package com.lti.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.lti.bean.Customer;
import com.lti.util.DbUtil;

public class CustomerDaoImpl implements CustomerDao {
	DbUtil util = null;
	Connection conn = null;
	
	public CustomerDaoImpl() {
		util = new DbUtil();
	}
	
	@Override
	public int addCustomer(int custId, String custName, double balance) throws ClassNotFoundException, SQLException {
		conn= util.getDataSource();
		PreparedStatement pst= conn.prepareStatement("Insert into Customer Values(?,?,?)");
		pst.setInt(1, custId);
		pst.setString(2, custName);
		pst.setDouble(3, balance);
		int count = pst.executeUpdate();
		return count;
	}

	@Override
	public int deleteCustomer(int custId) throws ClassNotFoundException, SQLException {
		conn= util.getDataSource();
		PreparedStatement pst= conn.prepareStatement("Delete From Customer Where CustomerId=?");
		pst.setInt(1, custId);
		int count = pst.executeUpdate();
		
		return count;
	}

	@Override
	public List<Customer> getAllCustomers() throws ClassNotFoundException {
		List<Customer> myList=null;			
		try
		{		
			myList= new ArrayList<>();			
			conn= util.getDataSource();
			Statement stmt= conn.createStatement();			
			ResultSet rs= stmt.executeQuery("Select * from Customer");			
			while(rs.next())
			{
				int custId=rs.getInt(1);
				String custName = rs.getString(2);
				double balance = rs.getDouble(3);
				Customer peop= new Customer(custId, custName, balance);
				myList.add(peop);		
			}
			return myList;	
			
		} catch (SQLException e) {
			e.printStackTrace();
			
		}
		finally{
			try {
				if(conn!=null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return myList;
	}

}
