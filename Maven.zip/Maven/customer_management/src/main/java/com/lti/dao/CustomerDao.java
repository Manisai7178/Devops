package com.lti.dao;

import java.sql.SQLException;
import java.util.List;

import com.lti.bean.Customer;

public interface CustomerDao {
	public int addCustomer(int custId, String custName, double balance) throws ClassNotFoundException, SQLException;
	public int deleteCustomer(int custId) throws ClassNotFoundException, SQLException;
	public List<Customer> getAllCustomers() throws ClassNotFoundException;
}
