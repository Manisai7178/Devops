package com.lti.service;

import java.sql.SQLException;
import java.util.List;

import com.lti.bean.Customer;
import com.lti.dao.CustomerDao;
import com.lti.dao.CustomerDaoImpl;

public class CustomerServiceImpl implements CustomerService {
	CustomerDao dao = null;
	
	public CustomerServiceImpl() {
		dao = new CustomerDaoImpl();
	}

	@Override
	public int addCustomer(int custId, String custName, double balance) throws ClassNotFoundException, SQLException {
		return dao.addCustomer(custId, custName, balance);
	}

	@Override
	public int deleteCustomer(int custId) throws ClassNotFoundException, SQLException {
		return dao.deleteCustomer(custId);
	}

	@Override
	public List<Customer> getAllCustomers() throws ClassNotFoundException {
		return dao.getAllCustomers();
	}

}
