package com.lti.bean;

public class Customer {
	private int custId;
	private String custName;
	private double balance;
	

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName + ", balance=" + balance + "]";
	}
	public Customer(int custId, String custName, double balance) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.balance = balance;
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
}
